# -*- coding: utf-8 -*-
"""
Created on Sun Jan 31 20:29:44 2021

@author: SVW_E
"""

#数据加载
import pandas as pd
df=pd.read_csv('car_complain.csv')
#数据处理
df=df.drop('problem',axis=1).join(df.problem.str.get_dummies(','))
#数据清洗
def f(x):
    x=x.replace('一汽-大众','一汽大众')
    return x
df['brand']=df['brand'].apply(f) 

#按照品牌统计投诉总量    
result=df.groupby(['brand'])['id'].agg(['count'])
result=result.sort_values('count',ascending=False)
print('各品牌投诉数量为')
print(result)


#按照车型统计投诉总量   
result3=df.groupby(['car_model'])['id'].agg(['count'])
result3=result3.sort_values('count',ascending=False)
print('各车型投诉数量为')
print(result3)


# 品牌车型抱怨数量统计
result4=df.groupby(['brand','car_model'])['id'].agg('count')
#计算各车型品牌数量
result5=result4.groupby(['brand']).agg('count')
#将各车型投诉量与品牌量结合在一起
result6=result.merge(result5,left_index=True, right_index=True, how='left')
#计算各车型平均品牌投诉数量
result6['average']=result6['count']/result6['id']
result6=result6.sort_values('average',ascending=False)
print('各品牌平均车型投诉从多到少为')
print(result6)




