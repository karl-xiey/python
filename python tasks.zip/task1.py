# -*- coding: utf-8 -*-
"""
Created on Sun Jan 31 17:26:20 2021

@author: SVW_EPEL_Xie Yanqing
"""

# # for循环
# sum = 0
# for number in range(2,101,2):
#       sum = sum + number
# print(sum)


# while循环
sum = 0
number = 2
while number < 101:
       sum = sum + number
       number = number + 2
print('2，4，6....100的和为')
print(sum)

